To run this program use following commnads:
- javac ClientApp.java
- java ClientApp
