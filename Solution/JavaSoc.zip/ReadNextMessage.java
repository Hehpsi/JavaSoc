public interface ReadNextMessage 
{
    Activity readNext();
}

/*
Explanation:
This is a Java interface named ReadNextMessage. 
It declares a single method called readNext() which returns an object of the Activity class.
*/